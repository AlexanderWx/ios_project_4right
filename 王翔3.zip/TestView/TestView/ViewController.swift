//
//  ViewController.swift
//  TestView
//
//  Created by AlexWx on 2019/9/24.
//  Copyright © 2019 AlexWx. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var nameText: UITextField!
    @IBOutlet weak var passwordText: UITextField!
    @IBOutlet weak var WelcomeLabel: UILabel!
    @IBAction func LoginButtton(_ sender: Any) {
        
        if (nameText.text == "AlexWx") && (passwordText.text == "123456"){
        if let userName = nameText.text{
            WelcomeLabel.text = "Login successful!  Welcome  " + userName
            }
        }
        else {
            WelcomeLabel.text = "Sorry，Wrong Username or Password"
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

