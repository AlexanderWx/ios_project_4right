import UIKit

var str = "Hello, playground"

func getPokers()->String{
    let Suit = ["Spade","Heart","Club","Diamond"]
    let Face = ["A","2","3","4","5","6","7","8","9","J","Q","K"]
    
    let randomNumber1:Int = Int(arc4random() % 4)
    let randomNumber2:Int = Int(arc4random() % 13)
    
    return (Suit[randomNumber1] + " " + Face[randomNumber2])
}

print(getPokers())//随机抽出一张牌

/*func getPoker(){
    let Poker = [ "sA", "s2", "s3", "s4", "s5", "s6", "s7", "s8", "s9", "s10", "sJ", "sQ", "sK", "hA", "h2", "h3", "h4", "h5", "h6", "h7", "h8", "h9", "h10", "hJ", "hQ", "hK", "cA", "c2", "c3", "c4", "c5", "c6", "c7", "c8", "c9", "c10", "cJ", "cQ", "cK", "dA", "d2", "d3", "d4", "d5", "d6", "d7", "d8", "d9", "d10", "dJ", "dQ", "dK"]
    
    let randomNumber:Int = Int(arc4random() % 52)
    
    var a = randomNumber
    
    print(Poker[a])
}

func getRandom(){
    let randomNumber:Int = Int(arc4random() % 52)
    print(randomNumber)
}

//var a = getRandom()*/


